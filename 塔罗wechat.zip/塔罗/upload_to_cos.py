#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
腾讯云 COS 图片上传脚本
需要安装: pip install cos-python-sdk-v5
"""

import os
import sys
from qcloud_cos import CosConfig
from qcloud_cos import CosS3Client
import glob

# ==================== 配置区域 ====================
# 请在腾讯云控制台获取以下信息：
# https://console.cloud.tencent.com/cam/capi

SECRET_ID = 'AKIDZBsS6YnqoZ9WhhXAcKtHSaZLtENL8i6M'
SECRET_KEY = 'JUNDvUPOH93qdO0RfgUChzGRWcidL4hO'
REGION = 'ap-nanjing'
BUCKET = '20260415-1419298315'
# ==================================================

def upload_images(local_dir, cos_folder='tarot-cards'):
    """
    上传图片到腾讯云 COS
    
    Args:
        local_dir: 本地图片目录
        cos_folder: COS 上的文件夹名称
    """
    
    # 检查配置
    if SECRET_ID == 'YOUR_SECRET_ID' or SECRET_KEY == 'YOUR_SECRET_KEY':
        print("❌ 错误: 请先配置 SECRET_ID 和 SECRET_KEY")
        print("请前往腾讯云控制台获取: https://console.cloud.tencent.com/cam/capi")
        return
    
    if BUCKET == 'YOUR_BUCKET_NAME':
        print("❌ 错误: 请先配置 BUCKET 名称")
        print("请前往腾讯云 COS 控制台创建存储桶")
        return
    
    # 配置 COS
    config = CosConfig(
        Region=REGION,
        SecretId=SECRET_ID,
        SecretKey=SECRET_KEY,
        Token=None,
        Scheme='https'
    )
    client = CosS3Client(config)
    
    # 获取所有图片
    image_files = glob.glob(os.path.join(local_dir, '*.jpg'))
    image_files.extend(glob.glob(os.path.join(local_dir, '*.png')))
    
    print(f"找到 {len(image_files)} 张图片")
    print(f"目标存储桶: {BUCKET}")
    print(f"目标目录: {cos_folder}/")
    print("=" * 60)
    
    success_count = 0
    failed_files = []
    
    for i, image_path in enumerate(sorted(image_files), 1):
        filename = os.path.basename(image_path)
        cos_key = f"{cos_folder}/{filename}"
        
        print(f"\n[{i}/{len(image_files)}] 上传: {filename}")
        
        try:
            with open(image_path, 'rb') as fp:
                response = client.put_object(
                    Bucket=BUCKET,
                    Body=fp,
                    Key=cos_key,
                    StorageClass='STANDARD',
                    ContentType='image/jpeg'
                )
            
            # 生成访问 URL
            url = f"https://{BUCKET}.cos.{REGION}.myqcloud.com/{cos_key}"
            print(f"  ✅ 成功: {url}")
            success_count += 1
            
        except Exception as e:
            print(f"  ❌ 失败: {e}")
            failed_files.append(filename)
    
    # 打印总结
    print("\n" + "=" * 60)
    print("上传完成!")
    print(f"成功: {success_count}/{len(image_files)}")
    
    if failed_files:
        print(f"\n失败的文件:")
        for f in failed_files:
            print(f"  - {f}")
    
    if success_count > 0:
        print(f"\n图片访问地址格式:")
        print(f"https://{BUCKET}.cos.{REGION}.myqcloud.com/{cos_folder}/0.jpg")
        print(f"https://{BUCKET}.cos.{REGION}.myqcloud.com/{cos_folder}/1.jpg")
        print(f"...")
        print(f"\n请将此地址格式更新到代码中")

def main():
    # 图片目录
    image_dir = "tarotrws-78cards"
    
    if not os.path.exists(image_dir):
        print(f"❌ 找不到图片目录: {image_dir}")
        print("请确认图片已准备好")
        return
    
    upload_images(image_dir)

if __name__ == "__main__":
    main()
