# 腾讯云 COS 配置指南

## 步骤一：注册腾讯云账号
1. 访问 https://cloud.tencent.com/
2. 注册并登录账号

## 步骤二：创建存储桶
1. 进入 [COS 控制台](https://console.cloud.tencent.com/cos/bucket)
2. 点击 **创建存储桶**
3. 配置信息：
   - **名称**: `tarot-images` (或你喜欢的名字)
   - **地域**: 选择离你最近的地域，如 `广州`
   - **访问权限**: **公有读私有写** (重要！)
   - **其他**: 保持默认
4. 点击 **创建**

## 步骤三：获取 API 密钥
1. 进入 [API 密钥管理](https://console.cloud.tencent.com/cam/capi)
2. 点击 **新建密钥**
3. 记录 **SecretId** 和 **SecretKey**

## 步骤四：配置上传脚本
编辑 `upload_to_cos.py` 文件，填入你的信息：

```python
SECRET_ID = 'AKIDZBsS6YnqoZ9WhhXAcKtHSaZLtENL8i6M'
SECRET_KEY = 'JUNDvUPOH93qdO0RfgUChzGRWcidL4hO'
REGION = 'ap-nanjing'  # 根据你的存储桶地域修改
BUCKET = '20260415-1419298315'  # 存储桶名称
```

## 步骤五：安装依赖并上传
```bash
# 安装腾讯云 COS SDK
pip install cos-python-sdk-v5

# 运行上传脚本
python upload_to_cos.py
```

## 步骤六：配置小程序域名白名单
1. 登录 [微信公众平台](https://mp.weixin.qq.com/)
2. 进入 **开发 → 开发管理 → 开发设置**
3. 找到 **服务器域名** → **downloadFile 合法域名**
4. 添加你的 COS 域名：
   ```
   https://tarot-images-你的APPID.cos.ap-guangzhou.myqcloud.com
   ```

## 步骤七：更新代码中的图片路径
上传完成后，脚本会输出图片访问地址格式，类似：
```
https://tarot-images-12345678.cos.ap-guangzhou.myqcloud.com/tarot-cards/0.jpg
```

告诉我这个地址格式，我会帮你更新代码中的所有图片路径。

---

## 费用说明
- 腾讯云 COS 有 **50GB 免费额度**
- 78 张塔罗牌图片约 8-10MB，完全在免费范围内
- 每月前 50GB 流量免费
