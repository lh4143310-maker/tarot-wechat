---
name: fix-tarot-card-images
overview: 修复占卜师入口的牌面解读页面中塔罗牌图片无法显示的问题，将外部API图片链接替换为可靠方案。
todos:
  - id: fix-tarot-data
    content: 清空 data/tarotCards.js 中全部26张牌的 image 字段值为空字符串
    status: completed
  - id: fix-card-parser-view
    content: 修改 card-parser.wxml 列表项和弹窗大图为条件渲染，并在 card-parser.wxss 中添加占位牌面样式
    status: completed
    dependencies:
      - fix-tarot-data
  - id: fix-draw-result-view
    content: 修改 draw.wxml 和 result.wxml 翻牌正面为条件渲染，并在对应 wxss 中添加占位牌面样式
    status: completed
    dependencies:
      - fix-tarot-data
---

## 用户需求

占卜师入口的牌面解读页（`card-parser`）以及抽牌结果页（`draw`、`result`）中，塔罗牌图片无法显示。

## 问题概述

`data/tarotCards.js` 中所有26张牌的 `image` 字段均指向文生图 API（`https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?...`），该域名不在微信小程序合法域名白名单中，且该接口为动态生成接口而非静态图片地址，导致所有依赖 `item.image` / `selectedCard.image` / `card.image` 的图片组件全部显示空白。

## 核心功能要求

- 修复 `data/tarotCards.js` 中全部26张牌的 `image` 字段，替换为本地可靠资源
- 在 `pages/diviner/card-parser.wxml` 的列表缩略图和弹窗大图中正常显示牌面
- 在 `pages/reading/draw.wxml` 的翻牌正面中正常显示牌面
- 在 `pages/reading/result.wxml` 的抽牌结果列表中正常显示牌面
- 图片区域在无外部网络时也能有合适的视觉呈现，风格与现有深色神秘塔罗主题保持一致

## 技术栈

微信小程序原生开发（WXML / WXSS / JS），无需引入新依赖。

## 实现方案

### 核心策略：本地 CSS 占位牌面 + 图片加载失败兜底

由于微信小程序对网络图片有严格的合法域名限制，且项目 `images/` 目录中没有实际塔罗牌图片，最可靠的方案是：

1. **将 `tarotCards.js` 中所有 `image` 字段置空（空字符串）**，不再依赖外部URL
2. **在 WXML 中用条件渲染**：当 `image` 为空时显示一个纯 CSS 绘制的塔罗牌正面占位视图，包含牌名和装饰元素，风格与现有深色金色主题一致
3. **在 CSS 中为占位牌面设计**：渐变背景 + 金色边框 + 牌名文字 + 星形/圆形装饰，与 `draw.wxss` 已有的 `.card-back-design` 风格保持统一

这样完全不依赖网络，且每张牌有差异化的展示（通过牌名区分），视觉上保持神秘感。

### 涉及文件范围

- `data/tarotCards.js`：清空所有 `image` 字段值
- `pages/diviner/card-parser.wxml`：列表项和弹窗均改为条件渲染（有图用 image，无图用占位 view）
- `pages/diviner/card-parser.wxss`：添加占位牌面样式（列表小尺寸 + 弹窗大尺寸）
- `pages/reading/draw.wxml`：翻牌正面改为条件渲染
- `pages/reading/draw.wxss`：添加 draw 页占位牌面样式
- `pages/reading/result.wxml`：结果列表改为条件渲染
- `pages/reading/result.wxss`：添加 result 页占位牌面样式

## 实现细节

### 占位牌面设计规范

与项目现有主题完全一致：

- **背景**：`linear-gradient(135deg, #2d004d 0%, #1a0a2e 100%)`（与 `.card-back` 一致）
- **边框**：`3rpx solid rgba(212, 175, 55, 0.6)`（金色）
- **牌名文字**：`color: #d4af37`，`font-family: 'Times New Roman', serif`
- **装饰**：顶部/底部金色横线分隔，中间圆形光晕（参考 `.card-back-design`）

### 条件渲染模式

```
<!-- 有图时用 image，无图时用 CSS 占位 -->
<image wx:if="{{item.image}}" src="{{item.image}}" mode="aspectFill" />
<view wx:else class="card-placeholder">
  <view class="placeholder-deco"></view>
  <view class="placeholder-name">{{item.name}}</view>
</view>
```

### 性能说明

- 不发起任何网络请求，渲染性能优于原方案
- 26张牌全部使用本地 CSS 渲染，列表滚动流畅无图片加载卡顿
- 后续如需真实图片，只需将 `image` 字段填入合法域名图片 URL 即可，无需修改 WXML 结构