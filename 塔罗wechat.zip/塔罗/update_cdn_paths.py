#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
更新塔罗牌图片路径为腾讯云 COS 地址
"""

import os
import re

# 腾讯云 COS 配置
COS_BASE_URL = "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards"

# 需要更新的文件列表
files_to_update = [
    "pages/reading/data/tarotCards.js",
    "pages/daily/data/tarotCards.js",
    "pages/diviner/data/tarotCards.js"
]

def get_image_filename(card_id):
    """根据卡牌ID获取对应的文件名"""
    # 大阿卡纳 (0-21)
    major_arcana = {
        0: "tarot-0-fool.jpg",
        1: "tarot-01-magician.jpg",
        2: "tarot-02-highpriestess.jpg",
        3: "tarot-03-empress.jpg",
        4: "tarot-04-emperor.jpg",
        5: "tarot-05-hierophant.jpg",
        6: "tarot-06-lovers.jpg",
        7: "tarot-07-chariot.jpg",
        8: "tarot-08-strength.jpg",
        9: "tarot-09-hermit.jpg",
        10: "tarot-10-wheeloffortune.jpg",
        11: "tarot-11-justice.jpg",
        12: "tarot-12-hangedman.jpg",
        13: "tarot-13-death.jpg",
        14: "tarot-14-temperance.jpg",
        15: "tarot-15-devil.jpg",
        16: "tarot-16-tower.jpg",
        17: "tarot-17-star.jpg",
        18: "tarot-18-moon.jpg",
        19: "tarot-19-sun.jpg",
        20: "tarot-20-judgement.jpg",
        21: "tarot-21-world.jpg"
    }
    
    if card_id in major_arcana:
        return major_arcana[card_id]
    
    # 小阿卡纳 (22-77)
    # 圣杯: 22-35 (cups-01 to cups-14)
    # 星币: 36-49 (pentacles-01 to pentacles-14)
    # 宝剑: 50-63 (swords-01 to swords-14)
    # 权杖: 64-77 (wands-01 to wands-14)
    
    if 22 <= card_id <= 35:
        num = card_id - 21
        return f"tarot-cups-{num:02d}.jpg"
    elif 36 <= card_id <= 49:
        num = card_id - 35
        return f"tarot-pentacles-{num:02d}.jpg"
    elif 50 <= card_id <= 63:
        num = card_id - 49
        return f"tarot-swords-{num:02d}.jpg"
    elif 64 <= card_id <= 77:
        num = card_id - 63
        return f"tarot-wands-{num:02d}.jpg"
    
    return None

def update_file(file_path):
    """更新单个文件中的图片路径"""
    
    if not os.path.exists(file_path):
        print(f"❌ 文件不存在: {file_path}")
        return False
    
    print(f"\n处理文件: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 统计替换次数
    replace_count = 0
    
    # 匹配 image: "https://cdn.jsdelivr.net/gh/lh4143310-maker/tarot-images/数字.jpg"
    pattern = r'image:\s*"https://cdn\.jsdelivr\.net/gh/lh4143310-maker/tarot-images/(\d+)\.jpg"'
    
    def replace_match(match):
        nonlocal replace_count
        card_id = int(match.group(1))
        filename = get_image_filename(card_id)
        if filename:
            replace_count += 1
            return f'image: "{COS_BASE_URL}/{filename}"'
        return match.group(0)
    
    new_content = re.sub(pattern, replace_match, content)
    
    # 保存文件
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"  ✅ 完成，替换了 {replace_count} 处")
    return True

def main():
    print("=" * 60)
    print("更新塔罗牌图片路径为腾讯云 COS 地址")
    print("=" * 60)
    
    success_count = 0
    
    for file_path in files_to_update:
        if update_file(file_path):
            success_count += 1
    
    print("\n" + "=" * 60)
    print(f"更新完成! 成功处理 {success_count}/{len(files_to_update)} 个文件")
    print("=" * 60)

if __name__ == "__main__":
    main()
