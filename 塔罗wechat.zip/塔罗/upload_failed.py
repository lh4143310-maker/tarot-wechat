#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
重新上传失败的图片到腾讯云 COS
"""

import os
import time
from qcloud_cos import CosConfig
from qcloud_cos import CosS3Client

# ==================== 配置区域 ====================
SECRET_ID = 'AKIDZBsS6YnqoZ9WhhXAcKtHSaZLtENL8i6M'
SECRET_KEY = 'JUNDvUPOH93qdO0RfgUChzGRWcidL4hO'
REGION = 'ap-nanjing'
BUCKET = '20260415-1419298315'
# ==================================================

# 失败的图片列表
failed_images = [
    "tarot-10-wheeloffortune.jpg",
    "tarot-11-justice.jpg",
    "tarot-20-judgement.jpg",
    "tarot-21-world.jpg",
    "tarot-cups-01.jpg",
    "tarot-cups-02.jpg",
    "tarot-cups-03.jpg",
    "tarot-cups-04.jpg",
    "tarot-cups-05.jpg",
    "tarot-cups-06.jpg",
    "tarot-cups-07.jpg",
    "tarot-cups-08.jpg",
    "tarot-cups-09.jpg",
    "tarot-cups-10.jpg",
    "tarot-cups-11.jpg",
    "tarot-cups-12.jpg"
]

def upload_failed_images(local_dir, cos_folder='tarot-cards'):
    """重新上传失败的图片"""
    
    # 配置 COS
    config = CosConfig(
        Region=REGION,
        SecretId=SECRET_ID,
        SecretKey=SECRET_KEY,
        Token=None,
        Scheme='https'
    )
    client = CosS3Client(config)
    
    print(f"需要重新上传: {len(failed_images)} 张图片")
    print(f"目标存储桶: {BUCKET}")
    print("=" * 60)
    
    success_count = 0
    still_failed = []
    
    for i, filename in enumerate(failed_images, 1):
        image_path = os.path.join(local_dir, filename)
        cos_key = f"{cos_folder}/{filename}"
        
        print(f"\n[{i}/{len(failed_images)}] 上传: {filename}")
        
        # 检查文件是否存在
        if not os.path.exists(image_path):
            print(f"  ❌ 文件不存在: {image_path}")
            still_failed.append(filename)
            continue
        
        # 重试3次
        for attempt in range(3):
            try:
                with open(image_path, 'rb') as fp:
                    response = client.put_object(
                        Bucket=BUCKET,
                        Body=fp,
                        Key=cos_key,
                        StorageClass='STANDARD',
                        ContentType='image/jpeg'
                    )
                
                url = f"https://{BUCKET}.cos.{REGION}.myqcloud.com/{cos_key}"
                print(f"  ✅ 成功: {url}")
                success_count += 1
                break
                
            except Exception as e:
                print(f"  ⚠️ 尝试 {attempt + 1}/3 失败: {e}")
                if attempt < 2:
                    time.sleep(2)  # 等待2秒后重试
                else:
                    print(f"  ❌ 最终失败")
                    still_failed.append(filename)
    
    # 打印总结
    print("\n" + "=" * 60)
    print("重新上传完成!")
    print(f"成功: {success_count}/{len(failed_images)}")
    
    if still_failed:
        print(f"\n仍然失败的文件:")
        for f in still_failed:
            print(f"  - {f}")

def main():
    image_dir = "tarotrws-78cards"
    
    if not os.path.exists(image_dir):
        print(f"❌ 找不到图片目录: {image_dir}")
        return
    
    upload_failed_images(image_dir)

if __name__ == "__main__":
    main()
