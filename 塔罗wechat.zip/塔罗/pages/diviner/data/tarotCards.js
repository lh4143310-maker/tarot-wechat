const tarotCards = [
  {
    id: 0,
    name: "愚者",
    nameEn: "The Fool",
    type: "大阿卡纳",
    meaning: "新的开始、冒险、天真、自发性",
    upright: "新的开始、冒险、天真、自发性、信念、自由",
    reversed: "鲁莽、冒险带来的风险、愚蠢、疏忽、轻率",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-0-fool.jpg"
  },
  {
    id: 1,
    name: "魔术师",
    nameEn: "The Magician",
    type: "大阿卡纳",
    meaning: "创造力、技能、意志力、自信",
    upright: "创造力、技能、意志力、自信、行动、显化",
    reversed: "欺骗、操控、意志薄弱、滥用技能、不诚实",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-01-magician.jpg"
  },
  {
    id: 2,
    name: "女祭司",
    nameEn: "The High Priestess",
    type: "大阿卡纳",
    meaning: "直觉、神秘、潜意识、智慧",
    upright: "直觉、神秘、潜意识、智慧、内在知识、静止",
    reversed: "隐藏的动机、压抑的情感、表面化、忽视直觉",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-02-highpriestess.jpg"
  },
  {
    id: 3,
    name: "女皇",
    nameEn: "The Empress",
    type: "大阿卡纳",
    meaning: "丰饶、母性、自然、创造力",
    upright: "丰饶、母性、自然、创造力、孕育、感官享受",
    reversed: "创造力受阻、依赖、空虚、不安全感、缺乏成长",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-03-empress.jpg"
  },
  {
    id: 4,
    name: "皇帝",
    nameEn: "The Emperor",
    type: "大阿卡纳",
    meaning: "权威、结构、控制、父性",
    upright: "权威、结构、控制、父性、稳定、领导力",
    reversed: "独裁、僵化、冷酷、缺乏纪律、过度控制",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-04-emperor.jpg"
  },
  {
    id: 5,
    name: "教皇",
    nameEn: "The Hierophant",
    type: "大阿卡纳",
    meaning: "传统、信仰、精神指导、教育",
    upright: "传统、信仰、精神指导、教育、conformity、宗教",
    reversed: "非传统、挑战权威、新的信仰、打破常规、个人主义",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-05-hierophant.jpg"
  },
  {
    id: 6,
    name: "恋人",
    nameEn: "The Lovers",
    type: "大阿卡纳",
    meaning: "爱、和谐、关系、价值观的选择",
    upright: "爱、和谐、关系、价值观的选择、伙伴关系、团结",
    reversed: "不和谐、失衡、价值观冲突、分离、错误的选择",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-06-lovers.jpg"
  },
  {
    id: 7,
    name: "战车",
    nameEn: "The Chariot",
    type: "大阿卡纳",
    meaning: "意志、胜利、控制、决心",
    upright: "意志、胜利、控制、决心、行动力、征服",
    reversed: "失去方向、失控、攻击性、缺乏纪律、失败",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-07-chariot.jpg"
  },
  {
    id: 8,
    name: "力量",
    nameEn: "Strength",
    type: "大阿卡纳",
    meaning: "勇气、耐心、同情、内在力量",
    upright: "勇气、耐心、同情、内在力量、韧性、信心",
    reversed: "软弱、自我怀疑、缺乏自律、不安全感、失控",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-08-strength.jpg"
  },
  {
    id: 9,
    name: "隐士",
    nameEn: "The Hermit",
    type: "大阿卡纳",
    meaning: "内省、孤独、寻求真理、内在引导",
    upright: "内省、孤独、寻求真理、内在引导、沉思、智慧",
    reversed: "孤立、孤独、退缩、拒绝帮助、迷失方向",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-09-hermit.jpg"
  },
  {
    id: 10,
    name: "命运之轮",
    nameEn: "Wheel of Fortune",
    type: "大阿卡纳",
    meaning: "命运、周期、变化、机遇",
    upright: "命运、周期、变化、机遇、好运、转折点",
    reversed: "厄运、抗拒变化、失控、坏运气、中断",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-10-wheeloffortune.jpg"
  },
  {
    id: 11,
    name: "正义",
    nameEn: "Justice",
    type: "大阿卡纳",
    meaning: "公平、真理、因果、法律",
    upright: "公平、真理、因果、法律、公正、责任",
    reversed: "不公、不诚实、逃避责任、不公正、偏见",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-11-justice.jpg"
  },
  {
    id: 12,
    name: "倒吊人",
    nameEn: "The Hanged Man",
    type: "大阿卡纳",
    meaning: "牺牲、新视角、等待、放下",
    upright: "牺牲、新视角、等待、放下、转变、放手",
    reversed: "拖延、无谓的牺牲、停滞、抗拒改变、固执",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-12-hangedman.jpg"
  },
  {
    id: 13,
    name: "死神",
    nameEn: "Death",
    type: "大阿卡纳",
    meaning: "结束、转变、重生、新的开始",
    upright: "结束、转变、重生、新的开始、过渡、放下",
    reversed: "抗拒改变、停滞、无法放手、拖延、恐惧变化",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-13-death.jpg"
  },
  {
    id: 14,
    name: "节制",
    nameEn: "Temperance",
    type: "大阿卡纳",
    meaning: "平衡、适度、耐心、和谐",
    upright: "平衡、适度、耐心、和谐、自我控制、融合",
    reversed: "失衡、过度、缺乏耐心、冲突、不和谐",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-14-temperance.jpg"
  },
  {
    id: 15,
    name: "恶魔",
    nameEn: "The Devil",
    type: "大阿卡纳",
    meaning: "束缚、物质主义、欲望、黑暗面",
    upright: "束缚、物质主义、欲望、黑暗面、成瘾、无知",
    reversed: "释放、摆脱束缚、重获力量、面对黑暗面、独立",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-15-devil.jpg"
  },
  {
    id: 16,
    name: "塔",
    nameEn: "The Tower",
    type: "大阿卡纳",
    meaning: "突变、觉醒、混乱、启示",
    upright: "突变、觉醒、混乱、启示、破坏、真相",
    reversed: "避免灾难、恐惧改变、推迟不可避免的、内在变化",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-16-tower.jpg"
  },
  {
    id: 17,
    name: "星星",
    nameEn: "The Star",
    type: "大阿卡纳",
    meaning: "希望、灵感、宁静、更新",
    upright: "希望、灵感、宁静、更新、信心、平静",
    reversed: "绝望、缺乏信心、失望、消极、不切实际",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-17-star.jpg"
  },
  {
    id: 18,
    name: "月亮",
    nameEn: "The Moon",
    type: "大阿卡纳",
    meaning: "幻觉、恐惧、潜意识、直觉",
    upright: "幻觉、恐惧、潜意识、直觉、不确定性、梦境",
    reversed: "释放恐惧、真相大白、压抑的情感、清晰",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-18-moon.jpg"
  },
  {
    id: 19,
    name: "太阳",
    nameEn: "The Sun",
    type: "大阿卡纳",
    meaning: "积极、成功、活力、喜悦",
    upright: "积极、成功、活力、喜悦、清晰、庆祝",
    reversed: "暂时的消沉、过度乐观、缺乏成功、虚假的乐观",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-19-sun.jpg"
  },
  {
    id: 20,
    name: "审判",
    nameEn: "Judgement",
    type: "大阿卡纳",
    meaning: "审判、觉醒、救赎、重生",
    upright: "审判、觉醒、救赎、重生、召唤、决定",
    reversed: "自我怀疑、拒绝召唤、忽视内在声音、缺乏自我审视",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-20-judgement.jpg"
  },
  {
    id: 21,
    name: "世界",
    nameEn: "The World",
    type: "大阿卡纳",
    meaning: "完成、整合、成就、旅行",
    upright: "完成、整合、成就、旅行、圆满、统一",
    reversed: "未完成、缺乏圆满、延迟、停滞、空虚",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-21-world.jpg"
  }
]

const smallCards = [
  {
    id: 22,
    name: "权杖首牌",
    nameEn: "Ace of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "新的开始、创造力、灵感",
    upright: "新的开始、创造力、灵感、行动力、潜力",
    reversed: "延迟、缺乏方向、创造力受阻、错失机会",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-01.jpg"
  },
  {
    id: 26,
    name: "权杖二",
    nameEn: "Two of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "规划、决策、未来方向",
    upright: "规划、决策、未来方向、探索、等待时机",
    reversed: "恐惧改变、缺乏计划、犹豫不决、错失机会",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-02.jpg"
  },
  {
    id: 27,
    name: "权杖三",
    nameEn: "Three of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "远见、扩展、进展",
    upright: "远见、扩展、进展、合作、初步成果",
    reversed: "延迟、缺乏远见、合作问题、目标未达成",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-03.jpg"
  },
  {
    id: 28,
    name: "权杖四",
    nameEn: "Four of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "庆祝、和谐、稳定",
    upright: "庆祝、和谐、稳定、家庭、社区、成就",
    reversed: "不稳定、缺乏支持、家庭问题、延迟庆祝",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-04.jpg"
  },
  {
    id: 29,
    name: "权杖五",
    nameEn: "Five of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "冲突、竞争、挑战",
    upright: "冲突、竞争、挑战、争论、能量过剩",
    reversed: "避免冲突、和解、合作、解决争端",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-05.jpg"
  },
  {
    id: 30,
    name: "权杖六",
    nameEn: "Six of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "胜利、认可、好消息",
    upright: "胜利、认可、好消息、自信、公众赞誉",
    reversed: "骄傲、过度自信、延迟的成功、缺乏认可",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-06.jpg"
  },
  {
    id: 31,
    name: "权杖七",
    nameEn: "Seven of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "防御、坚持、勇气",
    upright: "防御、坚持、勇气、对抗、保护立场",
    reversed: "放弃、不知所措、无法防御、疲惫",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-07.jpg"
  },
  {
    id: 32,
    name: "权杖八",
    nameEn: "Eight of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "快速行动、进展、消息",
    upright: "快速行动、进展、消息、旅行、动力",
    reversed: "延迟、阻碍、混乱、缺乏方向、挫折",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-08.jpg"
  },
  {
    id: 33,
    name: "权杖九",
    nameEn: "Nine of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "韧性、准备、坚持",
    upright: "韧性、准备、坚持、防御、最后努力",
    reversed: "疲惫、放弃、缺乏准备、固执、偏执",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-09.jpg"
  },
  {
    id: 34,
    name: "权杖十",
    nameEn: "Ten of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "负担、责任、压力",
    upright: "负担、责任、压力、努力工作、即将完成",
    reversed: "释放负担、委派、不堪重负、需要休息",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-10.jpg"
  },
  {
    id: 35,
    name: "权杖侍从",
    nameEn: "Page of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "探索、新想法、热情",
    upright: "探索、新想法、热情、创意、自由精神",
    reversed: "缺乏方向、冲动、不成熟、延迟消息",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-11.jpg"
  },
  {
    id: 36,
    name: "权杖骑士",
    nameEn: "Knight of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "行动、冒险、冲动",
    upright: "行动、冒险、冲动、热情、旅行",
    reversed: "冲动、鲁莽、延迟、愤怒、缺乏方向",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-12.jpg"
  },
  {
    id: 37,
    name: "权杖王后",
    nameEn: "Queen of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "自信、热情、社交",
    upright: "自信、热情、社交、魅力、独立",
    reversed: "嫉妒、专横、缺乏自信、自私",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-13.jpg"
  },
  {
    id: 38,
    name: "权杖国王",
    nameEn: "King of Wands",
    type: "小阿卡纳",
    suit: "权杖",
    meaning: "领导力、远见、创业",
    upright: "领导力、远见、创业、魅力、掌控",
    reversed: "专横、冲动、缺乏方向、暴怒",
    image: "https://20260415-1419298315.cos.ap-nanjing.myqcloud.com/tarot-cards/tarot-wands-14.jpg"
  }
]

const allCards = [...tarotCards, ...smallCards];

module.exports = {
  tarotCards: allCards
}