#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量替换 tarotCards.js 中的图片路径
从本地路径改为 jsDelivr CDN 路径
"""

import re

# CDN 基础地址
CDN_BASE = "https://cdn.jsdelivr.net/gh/lh4143310-maker/tarot-images"

def update_image_paths(file_path):
    """更新文件中的图片路径"""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 统计原始路径数量
    original_count = len(re.findall(r'/pages/reading/tarot-images/\d+\.jpg', content))
    print(f"找到 {original_count} 个本地图片路径")
    
    # 替换大阿卡纳和小阿卡纳的正确路径
    # 将 /pages/reading/tarot-images/0.jpg 替换为 CDN 地址
    updated_content = re.sub(
        r'image: "/pages/reading/tarot-images/(\d+)\.jpg"',
        f'image: "{CDN_BASE}/\\1.jpg"',
        content
    )
    
    # 统计替换后的路径数量
    new_count = len(re.findall(rf'{CDN_BASE}/\d+\.jpg', updated_content))
    print(f"替换为 {new_count} 个 CDN 路径")
    
    # 写回文件
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(updated_content)
    
    print(f"✅ 文件已更新: {file_path}")
    return original_count, new_count

def main():
    # 需要更新的文件列表
    files_to_update = [
        "pages/reading/data/tarotCards.js",
        "pages/daily/data/tarotCards.js",
        "pages/diviner/data/tarotCards.js"
    ]
    
    total_original = 0
    total_new = 0
    
    for file_path in files_to_update:
        print(f"\n处理: {file_path}")
        try:
            orig, new = update_image_paths(file_path)
            total_original += orig
            total_new += new
        except FileNotFoundError:
            print(f"⚠️ 文件不存在，跳过: {file_path}")
        except Exception as e:
            print(f"❌ 错误: {e}")
    
    print(f"\n{'='*50}")
    print("处理完成!")
    print(f"总共替换: {total_original} 个路径")
    print(f"CDN 路径: {total_new} 个")

if __name__ == "__main__":
    main()
