#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
塔罗牌图片压缩脚本
目标：将图片压缩至 200KB 以下，同时保持可接受画质
"""

import os
from PIL import Image
import glob

def compress_image(input_path, output_path, max_size_kb=180, max_dimension=800):
    """
    压缩图片至目标大小以下
    
    Args:
        input_path: 输入图片路径
        output_path: 输出图片路径
        max_size_kb: 最大文件大小（KB）
        max_dimension: 最大边长（像素）
    """
    # 打开图片
    with Image.open(input_path) as img:
        # 转换为 RGB（处理 PNG 等格式）
        if img.mode in ('RGBA', 'P'):
            img = img.convert('RGB')
        
        # 获取原始尺寸
        width, height = img.size
        
        # 如果图片太大，先降低分辨率
        max_side = max(width, height)
        if max_side > max_dimension:
            ratio = max_dimension / max_side
            new_width = int(width * ratio)
            new_height = int(height * ratio)
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            print(f"  调整尺寸: {width}x{height} -> {new_width}x{new_height}")
        
        # 逐步降低质量直到文件大小符合要求
        quality = 85
        min_quality = 60
        
        while quality >= min_quality:
            # 保存为 JPEG
            img.save(output_path, 'JPEG', quality=quality, optimize=True)
            
            # 检查文件大小
            file_size_kb = os.path.getsize(output_path) / 1024
            
            if file_size_kb <= max_size_kb:
                print(f"  压缩成功: {file_size_kb:.1f}KB (质量{quality}%)")
                return True
            
            # 降低质量继续尝试
            quality -= 5
            print(f"  质量{quality+5}% 过大({file_size_kb:.1f}KB)，尝试质量{quality}%")
        
        # 如果质量降到最低还不行，进一步降低分辨率
        print(f"  警告: 即使最低质量也超过 {max_size_kb}KB，进一步降低分辨率")
        ratio = 0.7
        new_width = int(img.size[0] * ratio)
        new_height = int(img.size[1] * ratio)
        img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        img.save(output_path, 'JPEG', quality=70, optimize=True)
        
        file_size_kb = os.path.getsize(output_path) / 1024
        print(f"  最终压缩: {file_size_kb:.1f}KB (尺寸{new_width}x{new_height})")
        return True

def main():
    # 图片目录
    input_dir = "pages/reading/tarot-images"
    output_dir = "pages/reading/tarot-images-compressed"
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 获取所有图片
    image_patterns = ['*.jpg', '*.jpeg', '*.png']
    image_files = []
    for pattern in image_patterns:
        image_files.extend(glob.glob(os.path.join(input_dir, pattern)))
    
    print(f"找到 {len(image_files)} 张图片")
    print("=" * 60)
    
    # 统计信息
    total_original_size = 0
    total_compressed_size = 0
    success_count = 0
    
    for i, image_path in enumerate(sorted(image_files), 1):
        filename = os.path.basename(image_path)
        output_path = os.path.join(output_dir, filename.rsplit('.', 1)[0] + '.jpg')
        
        original_size = os.path.getsize(image_path) / 1024
        total_original_size += original_size
        
        print(f"\n[{i}/{len(image_files)}] {filename}")
        print(f"  原始大小: {original_size:.1f}KB")
        
        try:
            if compress_image(image_path, output_path):
                compressed_size = os.path.getsize(output_path) / 1024
                total_compressed_size += compressed_size
                success_count += 1
                
                # 计算压缩率
                ratio = (1 - compressed_size / original_size) * 100
                print(f"  压缩率: {ratio:.1f}%")
        except Exception as e:
            print(f"  错误: {e}")
    
    # 打印统计
    print("\n" + "=" * 60)
    print("压缩完成!")
    print(f"成功: {success_count}/{len(image_files)}")
    print(f"原始总大小: {total_original_size/1024:.1f}MB")
    print(f"压缩后总大小: {total_compressed_size/1024:.1f}MB")
    print(f"总体压缩率: {(1-total_compressed_size/total_original_size)*100:.1f}%")
    print(f"\n压缩后的图片保存在: {output_dir}")
    print("\n建议:")
    print("1. 检查压缩后的图片质量是否可接受")
    print("2. 如果满意，将原目录备份后替换")
    print("3. 命令: Remove-Item -Recurse tarot-images; Rename-Item tarot-images-compressed tarot-images")

if __name__ == "__main__":
    main()
